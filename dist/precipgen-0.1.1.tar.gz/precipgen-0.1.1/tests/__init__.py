"""
Test suite for PrecipGen library.
"""